# import os
# import logging
# from fastapi import FastAPI, File, UploadFile, HTTPException
# from fastapi.responses import HTMLResponse
# from PIL import Image
# import numpy as np
# import cv2
# from paddleocr import PaddleOCR
# from ultralytics import YOLO
# import io
# import asyncio
# from concurrent.futures import ProcessPoolExecutor

# os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

# logging.basicConfig(level=logging.CRITICAL)
# logger = logging.getLogger('ppocr')
# logger.setLevel(logging.CRITICAL)

# for key in logging.Logger.manager.loggerDict.keys():
#     logging.getLogger(key).setLevel(logging.CRITICAL)

# app = FastAPI()
# model = YOLO('best.pt')
# ocr = PaddleOCR(use_angle_cls=True, lang='en')

# executor = ProcessPoolExecutor()

# def preprocess_for_ocr(image):
#     gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
#     processed = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
#                                       cv2.THRESH_BINARY, 11, 2)
#     return processed

# def extract_text(image, boxes):
#     texts = []
#     for box in boxes:
#         x1, y1, x2, y2 = map(int, box)
#         segment = image[y1:y2, x1:x2]
#         preprocessed_segment = preprocess_for_ocr(segment)
#         result = ocr.ocr(preprocessed_segment, cls=False)
#         text = ' '.join([line[1][0] for line in result[0]])
#         texts.append(text)
#     return texts

# @app.get("/", response_class=HTMLResponse)
# async def get_upload_page():
#     return """
#     <!DOCTYPE html>
#     <html>
#     <body>
#         <h2>Upload Image</h2>
#         <form action="/upload/" method="post" enctype="multipart/form-data">
#             <input type="file" name="file" accept="image/*">
#             <input type="submit" value="Upload">
#         </form>
#     </body>
#     </html>
#     """

# @app.post("/upload/")
# async def upload_image(file: UploadFile = File(...)):
#     if not file.filename:
#         raise HTTPException(status_code=400, detail="No file uploaded")
    
#     image = Image.open(io.BytesIO(await file.read()))
#     if image.mode == 'RGBA':
#         image = image.convert('RGB')
#     image_np = np.array(image)
    
#     loop = asyncio.get_event_loop()

#     # Run object detection in a separate process
#     results = await loop.run_in_executor(executor, lambda: model.predict(image_np))
#     boxes = results[0].boxes.xyxy.numpy()

#     # Run OCR in a separate process
#     extracted_texts = await loop.run_in_executor(executor, lambda: extract_text(image_np, boxes))
    
#     result_html = "<h2>Extracted Texts</h2>"
#     for text in extracted_texts:
#         result_html += f"<p>{text}</p>"
    
#     return HTMLResponse(content=result_html)

# if __name__ == "__main__":
#     import uvicorn
#     uvicorn.run("ex3:app", host="127.0.0.1", port=8000,reload=True)
import os
import logging
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse
from PIL import Image
import numpy as np
import cv2
from paddleocr import PaddleOCR
from ultralytics import YOLO
import io
import asyncio
from concurrent.futures import ProcessPoolExecutor

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('ppocr')
logger.setLevel(logging.INFO)

for key in logging.Logger.manager.loggerDict.keys():
    logging.getLogger(key).setLevel(logging.INFO)

app = FastAPI()
model = YOLO('best.pt')  # Ensure 'best.pt' is the correct path
ocr = PaddleOCR(use_angle_cls=True, lang='en')

executor = ProcessPoolExecutor()

def preprocess_for_ocr(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    processed = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                      cv2.THRESH_BINARY, 11, 2)
    return processed

def extract_text_from_boxes(image, boxes):
    texts = []
    for box in boxes:
        x1, y1, x2, y2 = map(int, box)
        segment = image[y1:y2, x1:x2]
        preprocessed_segment = preprocess_for_ocr(segment)
        result = ocr.ocr(preprocessed_segment, cls=False)
        text = ' '.join([line[1][0] for line in result[0]])
        texts.append(text)
    return texts

def run_model_predict(image_np):
    results = model.predict(image_np)
    return results[0].boxes.xyxy.numpy()

@app.get("/", response_class=HTMLResponse)
async def get_upload_page():
    return """
    <!DOCTYPE html>
    <html>
    <body>
        <h2>Upload Image</h2>
        <form action="/upload/" method="post" enctype="multipart/form-data">
            <input type="file" name="file" accept="image/*">
            <input type="submit" value="Upload">
        </form>
    </body>
    </html>
    """

@app.post("/upload/")
async def upload_image(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")
    
    try:
        image = Image.open(io.BytesIO(await file.read()))
        if image.mode == 'RGBA':
            image = image.convert('RGB')
        image_np = np.array(image)
        
        loop = asyncio.get_event_loop()

        # Run object detection in a separate process
        boxes = await loop.run_in_executor(executor, run_model_predict, image_np)

        # Run OCR in a separate process
        extracted_texts = await loop.run_in_executor(executor, extract_text_from_boxes, image_np, boxes)
        
        result_html = "<h2>Extracted Texts</h2>"
        for text in extracted_texts:
            result_html += f"<p>{text}</p>"
        
        return HTMLResponse(content=result_html)
    
    except Exception as e:
        logger.error(f"Error processing file: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ex3:app", host="127.0.0.1", port=8000, reload=True)

import os
import logging
from fastapi import FastAPI, File, UploadFile, HTTPException
from fastapi.responses import HTMLResponse
from PIL import Image
import numpy as np
import cv2
from paddleocr import PaddleOCR
from ultralytics import YOLO
import io
import asyncio
from concurrent.futures import ProcessPoolExecutor

os.environ['KMP_DUPLICATE_LIB_OK'] = 'TRUE'

async def startup_event():
    global model, ocr
    cls_model_dir = r"C:\Users\LENOVO\Downloads\ch_ppocr_mobile_v2.0_cls_slim_train"
    det_model_dir = r"C:\Users\LENOVO\Downloads\en_PP-OCRv3_det_slim_distill_train"
    rec_model_dir = r"C:\Users\LENOVO\Downloads\en_PP-OCRv3_rec_slim_train"

    model = YOLO('best.pt') 
    ocr = PaddleOCR(
    use_angle_cls=True,
    lang='en',
    cls_model_dir=cls_model_dir,
    det_model_dir=det_model_dir,
    rec_model_dir=rec_model_dir
)


logging.basicConfig(level=logging.INFO)
logger = logging.getLogger('ppocr')
logger.setLevel(logging.INFO)

for key in logging.Logger.manager.loggerDict.keys():
    logging.getLogger(key).setLevel(logging.INFO)

app = FastAPI()

executor = ProcessPoolExecutor()

def preprocess_for_ocr(image):
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
    processed = cv2.adaptiveThreshold(gray, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                      cv2.THRESH_BINARY, 11, 2)
    return processed

def extract_text_from_boxes(image, boxes):
    texts = []
    for box in boxes:
        x1, y1, x2, y2 = map(int, box)
        segment = image[y1:y2, x1:x2]
        preprocessed_segment = preprocess_for_ocr(segment)
        result = ocr.ocr(preprocessed_segment, cls=False)
        text = ' '.join([line[1][0] for line in result[0]])
        texts.append(text)
    return texts

def run_model_predict(image_np):
    results = model.predict(image_np)
    return results[0].boxes.xyxy.numpy()

@app.get("/", response_class=HTMLResponse)
async def get_upload_page():
    return """
    <!DOCTYPE html>
    <html>
    <body>
        <h2>Upload Image</h2>
        <form action="/upload/" method="post" enctype="multipart/form-data">
            <input type="file" name="file" accept="image/*">
            <input type="submit" value="Upload">
        </form>
    </body>
    </html>
    """

@app.post("/upload/")
async def upload_image(file: UploadFile = File(...)):
    if not file.filename:
        raise HTTPException(status_code=400, detail="No file uploaded")
    
    try:
        image = Image.open(io.BytesIO(await file.read()))
        if image.mode == 'RGBA':
            image = image.convert('RGB')
        image_np = np.array(image)
        
        loop = asyncio.get_event_loop()

        # Run object detection in a separate process
        boxes = await loop.run_in_executor(executor, run_model_predict, image_np)

        # Run OCR in a separate process
        extracted_texts = await loop.run_in_executor(executor, extract_text_from_boxes, image_np, boxes)
        
        result_html = "<h2>Extracted Texts</h2>"
        for text in extracted_texts:
            result_html += f"<p>{text}</p>"
        
        return HTMLResponse(content=result_html)

    except Exception as e:
        logger.error(f"Error processing file: {e}")
        raise HTTPException(status_code=500, detail="Internal Server Error")

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("ex3:app", host="127.0.0.1", port=8000, reload=True)




