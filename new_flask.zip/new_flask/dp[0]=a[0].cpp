dp[0]=a[0]
int neg =0;
for(int i=0;i<n;i++){
    take = a[ind];
    if(i>1){
      take +=dp[i-2];
    }
    non-take = 0+dp[i-1];
    dp[i]=max(take,non-take);
}