from flask import Flask, render_template, request, redirect
import time
from paddleocr import PaddleOCR
from PIL import Image
import io
import numpy as np

app = Flask(__name__)
ocr = PaddleOCR(use_angle_cls=True, lang='en', use_gpu=True)

def process_image(image_stream):
    img = Image.open(image_stream)
    img_np = np.array(img)
    start_time = time.time()
    result = ocr.ocr(img_np, cls=True)
    texts = [line[1][0] for line in result[0]]
    ocr_time = time.time() - start_time
    
    return texts, ocr_time

@app.route('/')
def index():
    return render_template('upload.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    file = request.files.get('file')
    if not file or file.filename == '':
        return redirect(request.url)
    
    texts, total_time = process_image(file.stream)
    
    return render_template('result.html', texts=texts, total_time=total_time)

if __name__ == '__main__':
    app.run(debug=True)