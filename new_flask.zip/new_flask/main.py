import requests
import time
import psutil
from datetime import datetime
from bs4 import BeautifulSoup
from concurrent.futures import ThreadPoolExecutor, as_completed

url = 'http://127.0.0.1:5000/upload'

def send_image_and_get_response(image_path, index):
    try:
        with open(image_path, 'rb') as img_file:
            start_time = time.time()
            response = requests.post(url, files={'file': img_file})
            upload_time = time.time() - start_time
            content_type = response.headers.get('Content-Type')
            response_content = response.text
            soup = BeautifulSoup(response_content, 'html.parser')
            extracted_texts = soup.get_text(separator='\n').strip().split('\n')
            result_time = time.time() - start_time
            
            return {
                'index': index,
                'upload_time': upload_time,
                'result_time': result_time,
                'extracted_texts': extracted_texts
            }
    except requests.exceptions.RequestException as e:
        print(f"Request failed: {e}")
        return None

def log_results(results):
    if results:
        with open('verifi.txt', 'a') as file:
            file.write(f"Image {results['index']}:\n")
            file.write(f"Extracted Texts: {results['extracted_texts']}\n")
            file.write(f"Upload Time: {results['upload_time']:.2f} seconds\n")
            file.write(f"Result Time: {results['result_time']:.2f} seconds\n")
            
            file.write("\n")
    
    return results['result_time'] if results else 0

def main():
    image_path = r'image.jpeg'
    total_time = 0

    for i in range(1000):
        result = send_image_and_get_response(image_path, i + 1)
        total_time += log_results(result)
            
    with open('tracker.txt', 'w') as file:
        file.write(f"Total Time for 100 Images: {total_time:.2f} seconds\n")
        file.write(f"Total Time for Upload and Processing: {total_time:.2f} seconds\n")

if __name__ == '__main__':
    main()
