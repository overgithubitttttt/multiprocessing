import requests
import time

url = 'http://127.0.0.1:8000/upload'
file_path = 'image.jpeg'

for i in range(100):
    start_time = time.time()
    with open(file_path, 'rb') as f:
        response = requests.post(url, files={'file': f})
    end_time = time.time()
    upload_time = end_time - start_time
    print(f"Image {i + 1}: processing time: {upload_time:.2f} seconds")